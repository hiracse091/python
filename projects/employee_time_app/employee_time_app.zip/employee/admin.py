from django.contrib import admin

from employee.models import UserProfile
# Register your models here.
admin.site.register(UserProfile)
